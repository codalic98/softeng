import { Component } from '@angular/core';

@Component({
  selector: 'app-prosumer-devices-page',
  templateUrl: './prosumer-devices-page.component.html',
  styleUrls: ['./prosumer-devices-page.component.css']
})
export class ProsumerDevicesPageComponent {

  
}
