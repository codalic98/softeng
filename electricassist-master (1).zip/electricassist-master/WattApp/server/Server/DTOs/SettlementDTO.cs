﻿namespace Server.DTOs
{
    public class SettlementDTO
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}
