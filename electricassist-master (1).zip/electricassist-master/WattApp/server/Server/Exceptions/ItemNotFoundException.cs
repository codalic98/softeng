﻿namespace Server.Exceptions
{
    public class ItemNotFoundException : Exception
    {
        public ItemNotFoundException(String message) : base(message)
        {

        }
    }
}
