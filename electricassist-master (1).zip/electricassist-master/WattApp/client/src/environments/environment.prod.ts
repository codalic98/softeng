export const environment = {
  production: true,
  serverUrl:"http://softeng.pmf.kg.ac.rs:10033",
  mapSearchUrl:"https://nominatim.openstreetmap.org/",
  openWeatherMapApiKey: '7dd14e5b21a93d6be27ec87a0694756b'
};
